package com.curewell.service;

import com.curewell.model.Surgery;
import com.curewell.repository.SurgeryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SurgeryService {

    @Autowired
    private SurgeryRepository surgeryRepository;

    public List<Surgery> getAllSurgeries() {
        return surgeryRepository.findAll();
    }

    public Surgery saveSurgery(Surgery surgery) {
        return surgeryRepository.save(surgery);
    }
}
